Unofficial experimental Glowing Eyes builds, LGPL-3.0-or-later.
The three source directories include license and attribution notices.
Fabric JARs were built from d30a2af, NeoForge JARs from ba087c0.
For matching versions, build as described in each source directory.
These builds are not tested in Minecraft.
